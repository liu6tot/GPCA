clear;

% (2,2,1) in R3
x=[0 2 4 6 8 12];
y1=[6 13 18.7 23.3 27.8 31.5];
figure(1); hold on;
plot(x,y1,'ko--', 'LineWidth',2);

% (4,2,2,1) in R5
y2=[8 14.4 36 48 49 50.7];
plot(x,y2,'k*-', 'LineWidth',2);