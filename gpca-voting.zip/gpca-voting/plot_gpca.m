figure(1); hold on
x=[0 2 4 8 12];
y1=[0 2.7 6.8 14.5 22.4];
plot(x,y1,'ko--','LineWidth',2);

y2=[0 3.9 7 15.3 29.2];
plot(x,y2,'k*-','LineWidth',2);